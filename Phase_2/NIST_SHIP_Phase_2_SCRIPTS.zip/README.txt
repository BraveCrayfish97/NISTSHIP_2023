ORDER OF EXECUTION
1. GroundTruthSort.py
2. ThresholdGeneration.py
3. STSGroundTruthGeneration.py


REQUIRED ARGS
GroundTruthSort.py - GroundTruthFolder
ThresholdGeneration.py - GroundTruthFolder
STSGroundTruthGeneration.py - GroundTruthFolder, RunsDataFolder


OUTPUT FORMAT - ThresholdData.txt
ID    Threshold


OUTPUT FORMAT - NewGroundTruth.txt
ID STS>Threshold Run-Submitted-Sentence